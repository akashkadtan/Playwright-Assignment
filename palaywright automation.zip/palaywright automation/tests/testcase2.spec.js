//Test case 2 :-  Search Order


import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://minimals.cc/');
  await page.getByRole('link', { name: 'Login' }).click();
  await page.getByLabel('Email address').click();
  await page.getByLabel('Email address').fill('demo@minimals.cc');
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('demo1234');
  await page.getByRole('button', { name: 'Login' }).click();
  await page.getByRole('button', { name: 'order' }).click();
  await page.getByRole('button', { name: 'list' }).click();
  await page.getByPlaceholder('Search customer or order').click();
  await page.getByPlaceholder('Search customer or order').fill('cor');
  await page.getByRole('row', { name: '#60111 Cortez Herring Cortez' }).getByRole('checkbox').check();
});
